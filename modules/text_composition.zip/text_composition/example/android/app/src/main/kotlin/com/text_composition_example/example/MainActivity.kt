package com.text_composition_example.text_composition_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
